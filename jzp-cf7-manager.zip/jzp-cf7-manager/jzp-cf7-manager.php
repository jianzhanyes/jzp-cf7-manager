<?php
/**
 * Plugin Name:       JZP CF7 Manager
 * Plugin URI:        https://www.jianzhanpress.com/?p=4622
 * Description:       将 Contact Form 7 提交的留言保存到数据库，在后台提供留言管理（查看、删除、批量删除、未读气泡提醒）功能。内置 SMTP 邮件设置，无需再安装 SMTP 插件。
 * Author:            Jianzhanpress.com
 * Author URI:        https://www.Jianzhanpress.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Version:           1.2.8
 * Requires at least: 7.1
 * Requires PHP:      8.0
 * Requires Plugins:  contact-form-7
 * Text Domain:       jzp-cf7-manager
 * Update URI:        https://wordpress.xz.cn
 */

if (!defined('ABSPATH')) {
    exit; // 禁止直接访问
}

define('JZP_CF7_VERSION', '1.2.8');

if (!defined('JZP_CF7_FILE')) {
    define('JZP_CF7_FILE', __FILE__);
}
if (!defined('JZP_CF7_UPDATE_API')) {
    define('JZP_CF7_UPDATE_API', 'https://wordpress.xz.cn/plugins/wp-update/jzp-cf7-manager/update.json');
}
if (!defined('JZP_CF7_UPDATE_CACHE_KEY')) {
    define('JZP_CF7_UPDATE_CACHE_KEY', 'jzp_cf7_manager_update_info');
}

// 1. 插件激活时创建数据表（这里用 after_setup_theme 只执行一次）
function jzp_cf7_custom_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'cf7_messages';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        form_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
        form_title VARCHAR(255) NOT NULL DEFAULT '',
        fields_data LONGTEXT NOT NULL,
        page_url VARCHAR(500) NOT NULL DEFAULT '',
        user_ip VARCHAR(100) NOT NULL DEFAULT '',
        status TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
        PRIMARY KEY (id),
        KEY form_id (form_id),
        KEY status (status)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);

    update_option('jzp_cf7_custom_db_version', '1.0');
}
add_action('after_setup_theme', 'jzp_cf7_custom_create_table');

// 插件激活时也确保表存在
register_activation_hook(__FILE__, 'jzp_cf7_custom_create_table');


// 2. 提交成功后保存数据
add_action('wpcf7_before_send_mail', 'jzp_cf7_save_submission_to_db', 10, 3);
function jzp_cf7_save_submission_to_db($contact_form, &$abort, $submission) {
    if ($abort) return;

    global $wpdb;
    $table_name = $wpdb->prefix . 'cf7_messages';

    // 获取所有提交字段
    $submission_data = $submission->get_posted_data();
    $form_id    = $contact_form->id();
    $form_title = $contact_form->title();

    // 过滤掉 CF7 内部字段（以 _ 开头的）
    $clean = array();
    foreach ($submission_data as $key => $value) {
        if (strpos($key, '_') === 0) continue;
        if (is_array($value)) {
            $value = implode(', ', array_map('sanitize_text_field', $value));
        }
        $clean[$key] = sanitize_text_field($value);
    }

    $page_url = isset($_SERVER['HTTP_REFERER']) ? esc_url_raw(wp_unslash($_SERVER['HTTP_REFERER'])) : '';
    $user_ip  = jzp_cf7_get_user_ip();

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $wpdb->insert(
        $table_name,
        array(
            'form_id'     => $form_id,
            'form_title'  => $form_title,
            'fields_data' => maybe_serialize($clean),
            'page_url'    => $page_url,
            'user_ip'     => $user_ip,
            'status'      => 0,
            'created_at'  => current_time('mysql'),
        ),
        array('%d', '%s', '%s', '%s', '%s', '%d', '%s')
    );
}

// 获取真实 IP
function jzp_cf7_get_user_ip() {
    $keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
    foreach ($keys as $key) {
        if (!empty($_SERVER[$key])) {
            $value = sanitize_text_field(wp_unslash($_SERVER[$key]));
            $ip = explode(',', $value);
            return trim($ip[0]);
        }
    }
    return '';
}


// 3. 添加后台管理菜单
add_action('admin_menu', 'jzp_cf7_admin_menu');
function jzp_cf7_admin_menu() {
    add_menu_page(
        '留言管理',
        '留言管理',
        'manage_options',
        'cf7-messages',
        'jzp_cf7_list_page',
        'dashicons-email-alt',
        26
    );

    // SMTP 设置子菜单
    add_submenu_page(
        'cf7-messages',
        'SMTP 设置',
        'SMTP 设置',
        'manage_options',
        'cf7-smtp-settings',
        'jzp_cf7_smtp_settings_page'
    );
}

// 4. 留言列表页面
function jzp_cf7_list_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'cf7_messages';

    // 处理删除
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
        if (!current_user_can('manage_options')) wp_die('无权限');
        check_admin_referer('jzp_cf7_delete_' . intval($_GET['id']));
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->delete($table_name, array('id' => intval($_GET['id'])), array('%d'));
        echo '<div class="notice notice-success is-dismissible"><p>删除成功！</p></div>';
    }

    // 处理批量删除
    if (isset($_POST['bulk_delete']) && !empty($_POST['ids'])) {
        if (!current_user_can('manage_options')) wp_die('无权限');
        check_admin_referer('jzp_cf7_bulk_action');
        $ids = array_map('intval', (array) $_POST['ids']);
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $wpdb->query($wpdb->prepare("DELETE FROM $table_name WHERE id IN ($placeholders)", $ids)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
        echo '<div class="notice notice-success is-dismissible"><p>批量删除成功！</p></div>';
    }

    // 分页
    $per_page = 20;
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($paged - 1) * $per_page;

    $total = $wpdb->get_var("SELECT COUNT(*) FROM $table_name"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
    $rows  = $wpdb->get_results($wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
        "SELECT * FROM $table_name ORDER BY created_at DESC LIMIT %d OFFSET %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $per_page, $offset
    ));

    $total_pages = ceil($total / $per_page);
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">留言管理</h1>
        <hr class="wp-header-end">

        <?php if (isset($_GET['view']) && intval($_GET['view'])):
            $id = intval($_GET['view']);
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id)); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
            if ($row):
                $fields = maybe_unserialize($row->fields_data);
        ?>
            <h2>留言详情 #<?php echo esc_html($row->id); ?></h2>
            <p><a href="<?php echo esc_url(admin_url('admin.php?page=cf7-messages')); ?>" class="button">← 返回列表</a></p>
            <table class="widefat striped" style="max-width:800px;">
                <tbody>
                    <tr><th style="width:180px;">表单名称</th><td><?php echo esc_html($row->form_title); ?> (ID: <?php echo esc_html($row->form_id); ?>)</td></tr>
                    <?php if (is_array($fields)): foreach ($fields as $k => $v): ?>
                        <tr><th><?php echo esc_html($k); ?></th><td><?php echo nl2br(esc_html($v)); ?></td></tr>
                    <?php endforeach; endif; ?>
                    <tr><th>来源页面</th><td><?php echo esc_html($row->page_url); ?></td></tr>
                    <tr><th>IP 地址</th><td><?php echo esc_html($row->user_ip); ?></td></tr>
                    <tr><th>提交时间</th><td><?php echo esc_html($row->created_at); ?></td></tr>
                </tbody>
            </table>
        <?php else: ?>
            <div class="notice notice-error"><p>未找到该留言。</p></div>
        <?php endif; else: ?>

        <form method="post">
            <?php wp_nonce_field('jzp_cf7_bulk_action'); ?>
            <div class="tablenav top">
                <div class="alignleft actions">
                    <button type="submit" name="bulk_delete" class="button action" onclick="return confirm('确定批量删除选中的留言吗？');">批量删除</button>
                </div>
                <div class="tablenav-pages">
                    <span class="displaying-num"><?php echo esc_html($total); ?> 条</span>
                    <?php
                    if ($total_pages > 1) {
                        echo wp_kses_post(paginate_links(array(
                            'base'      => add_query_arg('paged', '%#%'),
                            'format'    => '',
                            'current'   => $paged,
                            'total'     => $total_pages,
                            'prev_text' => '«',
                            'next_text' => '»',
                        )));
                    }
                    ?>
                </div>
            </div>

            <table class="widefat striped">
                <thead>
                    <tr>
                        <td style="width:30px;"><input type="checkbox" id="cb-all"></td>
                        <th style="width:60px;">ID</th>
                        <th>表单</th>
                        <th>内容摘要</th>
                        <th style="width:100px;">IP</th>
                        <th style="width:160px;">时间</th>
                        <th style="width:150px;">操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($rows)): ?>
                        <tr><td colspan="7">暂无留言。</td></tr>
                    <?php else: foreach ($rows as $row):
                        $fields = maybe_unserialize($row->fields_data);
                        $summary = '';
                        if (is_array($fields)) {
                            $i = 0;
                            foreach ($fields as $k => $v) {
                                if ($i >= 2) break;
                                $summary .= $k . ': ' . mb_substr($v, 0, 30) . ' | ';
                                $i++;
                            }
                            $summary = rtrim($summary, ' | ');
                        }
                        $view_url = admin_url('admin.php?page=cf7-messages&view=' . $row->id);
                        $del_url  = wp_nonce_url(admin_url('admin.php?page=cf7-messages&action=delete&id=' . $row->id), 'jzp_cf7_delete_' . $row->id);
                    ?>
                    <tr<?php echo empty($row->status) ? ' style="background-color:#fff9e6;font-weight:600;"' : ''; ?>>
                        <td><input type="checkbox" name="ids[]" value="<?php echo esc_attr($row->id); ?>" class="cb-item"></td>
                        <td><?php echo esc_html($row->id); ?></td>
                        <td><?php echo esc_html($row->form_title); ?></td>
                        <td><?php echo esc_html($summary); ?></td>
                        <td><?php echo esc_html($row->user_ip); ?></td>
                        <td><?php echo esc_html($row->created_at); ?></td>
                        <td>
                            <a href="<?php echo esc_url($view_url); ?>" class="button button-small">查看</a>
                            <a href="<?php echo esc_url($del_url); ?>" class="button button-small" onclick="return confirm('确定删除？');">删除</a>
                        </td>
                    </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </form>

        <script>
        document.getElementById('cb-all')?.addEventListener('change', function(){
            document.querySelectorAll('.cb-item').forEach(cb => cb.checked = this.checked);
        });
        </script>
        <?php endif; ?>
    </div>
    <?php
}


// 5. 后台菜单气泡显示未读数量（可选）
add_action('admin_menu', 'jzp_cf7_bubble', 999);
function jzp_cf7_bubble() {
    global $wpdb, $menu;
    $table_name = $wpdb->prefix . 'cf7_messages';
    $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE status = 0"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
    if ($count > 0 && is_array($menu)) {
        foreach ($menu as $k => $item) {
            if (isset($item[2]) && $item[2] === 'cf7-messages') {
                $menu[$k][0] .= sprintf(' <span class="update-plugins count-%d"><span class="plugin-count">%d</span></span>', $count, $count);
            }
        }
    }
}


// 6. 查看详情时自动标记为已读
add_action('admin_init', 'jzp_cf7_mark_as_read');
function jzp_cf7_mark_as_read() {
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    if (isset($_GET['page'], $_GET['view']) && $_GET['page'] === 'cf7-messages' && intval($_GET['view'])) {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update(
            $wpdb->prefix . 'cf7_messages',
            array('status' => 1),
            array('id' => intval($_GET['view'])), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            array('%d'),
            array('%d')
        );
    }
}


/* ============================================================
 * SMTP 邮件设置
 * ============================================================ */

// 7. SMTP 设置默认值
function jzp_cf7_smtp_get_defaults() {
    return array(
        'enabled'   => 0,
        'from_name' => get_bloginfo('name'),
        'from'      => get_option('admin_email'),
        'host'      => 'smtp.qq.com',
        'port'      => 465,
        'username'  => '',
        'password'  => '',
        'secure'    => 'ssl', // ssl / tls / 空
        'auth'      => 1,
    );
}

function jzp_cf7_smtp_get_settings() {
    return wp_parse_args(get_option('jzp_cf7_smtp_settings', array()), jzp_cf7_smtp_get_defaults());
}

// 8. 注册设置
add_action('admin_init', 'jzp_cf7_smtp_register_settings');
function jzp_cf7_smtp_register_settings() {
    register_setting('jzp_cf7_smtp_settings_group', 'jzp_cf7_smtp_settings', array(
        'sanitize_callback' => 'jzp_cf7_smtp_sanitize',
    ));
}

function jzp_cf7_smtp_sanitize($input) {
    $out = array();
    $out['enabled']   = !empty($input['enabled']) ? 1 : 0;
    $out['from_name'] = isset($input['from_name']) ? sanitize_text_field($input['from_name']) : '';
    $out['from']      = isset($input['from']) ? sanitize_email($input['from']) : '';
    $out['host']      = isset($input['host']) ? sanitize_text_field($input['host']) : '';
    $out['port']      = isset($input['port']) ? intval($input['port']) : 465;
    $out['username']  = isset($input['username']) ? sanitize_text_field($input['username']) : '';
    $out['password']  = isset($input['password']) ? sanitize_text_field($input['password']) : '';
    $out['secure']    = isset($input['secure']) && in_array($input['secure'], array('ssl', 'tls'), true) ? $input['secure'] : '';
    $out['auth']      = !empty($input['auth']) ? 1 : 0;
    return $out;
}

// 9. SMTP 设置页面
function jzp_cf7_smtp_settings_page() {
    $opt = jzp_cf7_smtp_get_settings();
    $current_tab = isset($_GET['tab']) ? sanitize_text_field(wp_unslash($_GET['tab'])) : 'smtp';

    // 发送测试邮件
    $test_result = null;
    if (isset($_POST['jzp_cf7_smtp_test']) && current_user_can('manage_options')) {
        check_admin_referer('jzp_cf7_smtp_test_action');
        $to = isset($_POST['test_email']) ? sanitize_email(wp_unslash($_POST['test_email'])) : '';
        if ($to) {
            $result = wp_mail($to, 'SMTP 测试邮件 - ' . get_bloginfo('name'), '这是一封来自「CF7 留言管理器」插件的 SMTP 测试邮件。如果您收到此邮件，说明 SMTP 配置正确。');
            $test_result = $result
                ? array('success' => '测试邮件发送成功，请查收 ' . esc_html($to) . ' 的收件箱（包括垃圾邮件文件夹）。')
                : array('error' => '测试邮件发送失败，请检查 SMTP 配置是否正确，或查看服务器错误日志。');
        } else {
            $test_result = array('error' => '请输入有效的收件邮箱地址。');
        }
    }
    ?>
    <div class="wrap">
        <h1>JZP CF7 Manager 设置</h1>

        <nav class="nav-tab-wrapper wp-clearfix">
            <?php
            $tabs = array(
                'smtp'  => 'SMTP 设置',
                'about' => '关于插件',
                'help'  => '使用帮助',
            );
            foreach ($tabs as $key => $label):
                $url = admin_url('admin.php?page=cf7-smtp-settings&tab=' . $key);
                $active = ($current_tab === $key) ? 'nav-tab-active' : '';
            ?>
                <a href="<?php echo esc_url($url); ?>" class="nav-tab <?php echo esc_attr($active); ?>"><?php echo esc_html($label); ?></a>
            <?php endforeach; ?>
        </nav>

        <?php if ('about' === $current_tab): ?>
            <div class="cf7-about-wrap">
                <h2>关于插件</h2>
                <table class="form-table" role="presentation">
                    <tr><th scope="row">插件名称</th><td>JZP CF7 Manager (JZP CF7 管理器)</td></tr>
                    <tr>
                        <th scope="row">版本号</th>
                        <td>
                            <?php echo esc_html(JZP_CF7_VERSION); ?>
                            <button type="button" class="button" id="cf7-check-update" style="margin-left:8px;">检查更新</button>
                            <span id="cf7-update-result" style="margin-left:8px;"></span>
                        </td>
                    </tr>
                    <tr><th scope="row">作者</th><td><a href="https://www.Jianzhanpress.com" target="_blank">Jianzhanpress.com</a></td></tr>
                    <tr><th scope="row">插件简介</th><td>将 Contact Form 7 提交的留言保存到数据库，并在后台提供留言管理功能。内置 SMTP 邮件设置，无需再安装额外的 SMTP 插件。</td></tr>
                    <tr><th scope="row">依赖</th><td>Contact Form 7（必需）、WordPress 7.1+、PHP 8.0+</td></tr>
                </table>

                <h3>更新日志</h3>
                <ul style="list-style:disc;padding-left:20px;">
                    <li><strong>v1.2.0</strong> — 留言列表支持未读行高亮；SMTP 设置页面新增「关于插件」与「使用帮助」tab。</li>
                    <li><strong>v1.1.0</strong> — 新增内置 SMTP 邮件设置功能（可视化配置 + 测试邮件）。</li>
                    <li><strong>v1.0.0</strong> — 首个版本发布：自动保存 CF7 留言到数据库，支持后台管理（查看、删除、批量删除）与未读标记。</li>
                </ul>
                <script>
                document.getElementById('cf7-check-update')?.addEventListener('click', function(){
                    var btn = this, result = document.getElementById('cf7-update-result');
                    btn.disabled = true; result.textContent = '检查中…';
                    fetch('<?php echo esc_url(admin_url("admin-ajax.php")); ?>', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'action=jzp_cf7_check_version&nonce=<?php echo esc_js(wp_create_nonce('jzp_cf7_check_version')); ?>'
                    })
                    .then(function(r){ return r.json(); })
                    .then(function(d){
                        btn.disabled = false;
                        if (!d.success) {
                            result.innerHTML = '<span style="color:#d63638;">' + (d.data.message || '检查失败') + '</span>';
                            return;
                        }
                        if (!d.data.is_latest) {
                            result.innerHTML = '<span style="color:#d63638;">发现新版本 <strong>' + d.data.latest + '</strong>（当前 ' + d.data.current + '）</span> ' +
                                '<a href="' + d.data.upgrade_url + '" class="button button-primary" style="margin-left:6px;">立即更新</a>';
                        } else {
                            result.innerHTML = '<span style="color:#00a32a;">已是最新版本 (' + d.data.current + ')</span>';
                        }
                    })
                    .catch(function(){
                        btn.disabled = false;
                        result.innerHTML = '<span style="color:#d63638;">网络错误，请稍后再试。</span>';
                    });
                });
                </script>
            </div>
            <?php return; ?>
        <?php endif; ?>

        <?php if ('help' === $current_tab): ?>
            <div class="cf7-help-wrap">
                <h2>使用帮助</h2>

                <h3 style="margin-top:20px;">快速开始</h3>
                <ol style="list-style:decimal;padding-left:24px;line-height:1.8;">
                    <li>确保已安装并启用 <strong>Contact Form 7</strong> 插件。</li>
                    <li>启用本插件后无需任何配置，CF7 的表单提交数据会自动保存。</li>
                    <li>进入后台左侧菜单「<strong>留言管理</strong>」即可查看所有提交的留言。</li>
                </ol>

                <h3 style="margin-top:24px;">留言管理</h3>
                <ul style="list-style:disc;padding-left:20px;line-height:1.8;">
                    <li><strong>未读高亮</strong> — 未读留言整行以淡黄色背景显示，并带有红点标记。</li>
                    <li><strong>查看详情</strong> — 点击「查看」进入详情页，留言会自动标记为已读。</li>
                    <li><strong>批量删除</strong> — 勾选多条留言后点击顶部「批量删除」按钮。</li>
                    <li><strong>未读提醒</strong> — 后台左侧菜单上会显示未读留言数量的红色气泡。</li>
                </ul>

                <h3 style="margin-top:24px;">SMTP 设置</h3>
                <ul style="list-style:disc;padding-left:20px;line-height:1.8;">
                    <li>进入「<strong>留言管理 → SMTP 设置</strong>」页面。</li>
                    <li>勾选「启用 SMTP 发送邮件」。</li>
                    <li>填写 SMTP 服务器、端口、账号和 <strong>授权码</strong>（不是邮箱登录密码）。</li>
                    <li>选择加密方式：QQ/163 邮箱通常用 SSL（端口 465），Gmail/Outlook 常用 TLS（端口 587）。</li>
                    <li>保存后在页面下方输入一个收件邮箱，点击「发送测试邮件」验证配置是否正确。</li>
                </ul>

                <h3 style="margin-top:24px;">常见 SMTP 参数</h3>
                <table class="widefat striped" style="max-width:600px;">
                    <thead><tr><th>服务商</th><th>服务器</th><th>端口</th><th>加密</th></tr></thead>
                    <tbody>
                        <tr><td>QQ 邮箱</td><td>smtp.qq.com</td><td>465</td><td>SSL</td></tr>
                        <tr><td>163 邮箱</td><td>smtp.163.com</td><td>465</td><td>SSL</td></tr>
                        <tr><td>Gmail</td><td>smtp.gmail.com</td><td>587</td><td>TLS</td></tr>
                        <tr><td>Outlook</td><td>smtp.office365.com</td><td>587</td><td>TLS</td></tr>
                    </tbody>
                </table>
                <p class="description" style="margin-top:8px;">以上参数仅供参考，具体请以各邮箱服务商的最新文档为准。</p>

                <h3 style="margin-top:24px;">安全卸载</h3>
                <p>在 WordPress 后台「插件」页面删除本插件时，会自动删除数据库中的留言数据表 `wp_cf7_messages` 和所有 SMTP 设置，不会在数据库中留下残留数据。如需保留数据，请先备份再卸载。</p>
            </div>
            <?php return; ?>
        <?php endif; ?>

        <?php if ($test_result): ?>
            <?php foreach ($test_result as $type => $msg): ?>
                <div class="notice notice-<?php echo $type === 'success' ? 'success' : 'error'; ?> is-dismissible"><p><?php echo esc_html($msg); ?></p></div>
            <?php endforeach; ?>
        <?php endif; ?>

        <form method="post" action="options.php">
            <?php settings_fields('jzp_cf7_smtp_settings_group'); ?>

            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row">启用 SMTP</th>
                    <td>
                        <label>
                            <input type="checkbox" name="jzp_cf7_smtp_settings[enabled]" value="1" <?php checked($opt['enabled'], 1); ?>>
                            启用 SMTP 发送邮件
                        </label>
                        <p class="description">未启用时，以下配置不会生效，网站使用默认的 PHP mail() 发送。</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="smtp_from_name">发件人名称</label></th>
                    <td><input type="text" id="smtp_from_name" name="jzp_cf7_smtp_settings[from_name]" value="<?php echo esc_attr($opt['from_name']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="smtp_from">发件人邮箱</label></th>
                    <td><input type="email" id="smtp_from" name="jzp_cf7_smtp_settings[from]" value="<?php echo esc_attr($opt['from']); ?>" class="regular-text">
                        <p class="description">通常需要和 SMTP 登录账号一致，否则可能被拒收。</p></td>
                </tr>
                <tr>
                    <th scope="row"><label for="smtp_host">SMTP 服务器</label></th>
                    <td><input type="text" id="smtp_host" name="jzp_cf7_smtp_settings[host]" value="<?php echo esc_attr($opt['host']); ?>" class="regular-text">
                        <p class="description">例如：QQ邮箱 smtp.qq.com / 163邮箱 smtp.163.com / Gmail smtp.gmail.com / Outlook smtp.office365.com</p>
						<p class="description"><a href="https://www.jianzhanpress.com/?p=9589" target="_blank">QQ邮箱开启SMTP的方法</a></p></td>
                </tr>
                <tr>
                    <th scope="row"><label for="smtp_port">SMTP 端口</label></th>
                    <td><input type="number" id="smtp_port" name="jzp_cf7_smtp_settings[port]" value="<?php echo esc_attr($opt['port']); ?>" class="small-text">
                        <p class="description">SSL 通常为 465，TLS 通常为 587。</p></td>
                </tr>
                <tr>
                    <th scope="row"><label for="smtp_username">SMTP 账号</label></th>
                    <td><input type="text" id="smtp_username" name="jzp_cf7_smtp_settings[username]" value="<?php echo esc_attr($opt['username']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="smtp_password">SMTP 授权码</label></th>
                    <td>
                        <input type="password" id="smtp_password" name="jzp_cf7_smtp_settings[password]" value="<?php echo esc_attr($opt['password']); ?>" class="regular-text" autocomplete="new-password">
                        <button type="button" class="button" onclick="var p=document.getElementById('smtp_password');p.type=p.type==='password'?'text':'password';">显示/隐藏</button>
                        <p class="description">注意：填写的不是邮箱登录密码，而是邮箱服务商提供的「授权码」（如 QQ 邮箱在 设置→账户 中生成）。</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">加密方式</th>
                    <td>
                        <label><input type="radio" name="jzp_cf7_smtp_settings[secure]" value="ssl" <?php checked($opt['secure'], 'ssl'); ?>> SSL（端口一般为 465）</label><br>
                        <label><input type="radio" name="jzp_cf7_smtp_settings[secure]" value="tls" <?php checked($opt['secure'], 'tls'); ?>> TLS（端口一般为 587）</label><br>
                        <label><input type="radio" name="jzp_cf7_smtp_settings[secure]" value="" <?php checked($opt['secure'], ''); ?>> 无加密（端口一般为 25，不建议）</label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">SMTP 认证</th>
                    <td>
                        <label><input type="checkbox" name="jzp_cf7_smtp_settings[auth]" value="1" <?php checked($opt['auth'], 1); ?>> 启用 SMTPAuth 认证</label>
                        <p class="description">绝大多数邮箱服务器都要求认证，保持勾选即可。</p>
                    </td>
                </tr>
            </table>

            <?php submit_button('保存设置'); ?>
        </form>

        <hr>
        <h2>发送测试邮件</h2>
        <form method="post">
            <?php wp_nonce_field('jzp_cf7_smtp_test_action'); ?>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="test_email">收件邮箱</label></th>
                    <td>
                        <input type="email" id="test_email" name="test_email" value="<?php echo esc_attr(get_option('admin_email')); ?>" class="regular-text">
                        <button type="submit" name="jzp_cf7_smtp_test" class="button button-primary">发送测试邮件</button>
                    </td>
                </tr>
            </table>
        </form>
    </div>
    <?php
}

// 10. 应用 SMTP 配置到 PHPMailer
add_action('phpmailer_init', 'jzp_cf7_smtp_configure');
function jzp_cf7_smtp_configure($phpmailer) {
    $opt = jzp_cf7_smtp_get_settings();

    if (empty($opt['enabled']) || empty($opt['host'])) {
        return;
    }

    $phpmailer->isSMTP();
    $phpmailer->Host       = $opt['host'];
    $phpmailer->Port       = intval($opt['port']);
    $phpmailer->SMTPAuth   = !empty($opt['auth']);
    $phpmailer->Username   = $opt['username'];
    $phpmailer->Password   = $opt['password'];
    $phpmailer->SMTPSecure = $opt['secure'];
    $phpmailer->From       = $opt['from'];
    $phpmailer->FromName   = $opt['from_name'];

    // 强制发件人与登录账号一致，避免部分邮箱服务器拒收
    $phpmailer->setFrom($opt['from'], $opt['from_name']);
}

// 10.5 插件自托管更新
if (!function_exists('jzp_cf7_get_update_cache_ttl')) {
    function jzp_cf7_get_update_cache_ttl() {
        return (int) apply_filters('jzp_cf7_update_cache_ttl', 12 * HOUR_IN_SECONDS);
    }
}

if (!function_exists('jzp_cf7_fetch_update')) {
    function jzp_cf7_fetch_update($force = false) {
        $cache_key = JZP_CF7_UPDATE_CACHE_KEY;

        if (!$force) {
            $cached = get_transient($cache_key);
            if (is_object($cached) && !empty($cached->version)) {
                return $cached;
            }
        }

        $url = apply_filters('jzp_cf7_update_api', JZP_CF7_UPDATE_API);
        if (empty($url) || !wp_http_validate_url($url)) {
            return false;
        }

        $response = wp_remote_get($url, array(
            'timeout'     => 12,
            'sslverify'   => true,
            'redirection' => 3,
            'user-agent'  => 'CF7-Messages-Manager/' . JZP_CF7_VERSION . '; ' . home_url(),
        ));

        if (is_wp_error($response)) {
            set_transient($cache_key, (object) array('error' => $response->get_error_message()), HOUR_IN_SECONDS);
            return false;
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if (200 !== $code) {
            set_transient($cache_key, (object) array('error' => 'HTTP ' . $code), HOUR_IN_SECONDS);
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body);

        if (JSON_ERROR_NONE !== json_last_error() || !is_object($data) || empty($data->version)) {
            set_transient($cache_key, (object) array('error' => 'Invalid JSON'), HOUR_IN_SECONDS);
            return false;
        }

        if (!preg_match('/^\d+(\.\d+)*/', (string) $data->version)) {
            return false;
        }

        if (!empty($data->download_url) && !wp_http_validate_url($data->download_url)) {
            $data->download_url = '';
        }

        set_transient($cache_key, $data, jzp_cf7_get_update_cache_ttl());
        return $data;
    }
}

// 自托管更新主钩子：pre_set_site_transient_update_plugins（行业标准方式）
if (!function_exists('jzp_cf7_inject_update')) {
    function jzp_cf7_inject_update($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }

        $plugin_basename = plugin_basename(JZP_CF7_FILE);
        if (!isset($transient->checked[$plugin_basename])) {
            return $transient;
        }

        $remote = jzp_cf7_fetch_update(false);
        if (!$remote || empty($remote->version)) {
            return $transient;
        }

        $current_version = $transient->checked[$plugin_basename];
        if (version_compare($remote->version, $current_version, '<=')) {
            return $transient;
        }

        $transient->response[$plugin_basename] = (object) array(
            'slug'         => isset($remote->slug) ? sanitize_title($remote->slug) : dirname($plugin_basename),
            'plugin'       => $plugin_basename,
            'new_version'  => sanitize_text_field($remote->version),
            'url'          => !empty($remote->homepage) ? esc_url_raw($remote->homepage) : '',
            'package'      => !empty($remote->download_url) ? esc_url_raw($remote->download_url) : '',
            'requires'     => isset($remote->requires) ? sanitize_text_field($remote->requires) : '',
            'requires_php' => isset($remote->requires_php) ? sanitize_text_field($remote->requires_php) : '',
            'tested'       => isset($remote->tested) ? sanitize_text_field($remote->tested) : '',
        );

        return $transient;
    }
}
add_filter('pre_set_site_transient_update_plugins', 'jzp_cf7_inject_update');

// WP 5.8+ Update URI 钩子（作为补充）
if (!function_exists('jzp_cf7_wp_58_update')) {
    function jzp_cf7_wp_58_update($update, $plugin_data, $plugin_file, $locales) {
        $plugin_basename = plugin_basename(JZP_CF7_FILE);
        if ($plugin_file !== $plugin_basename) {
            return $update;
        }

        $remote = jzp_cf7_fetch_update(false);
        if (!$remote || empty($remote->version)) {
            return $update;
        }

        $current_version = isset($plugin_data['Version']) ? $plugin_data['Version'] : JZP_CF7_VERSION;
        if (version_compare($remote->version, $current_version, '<=')) {
            return $update;
        }

        return (object) array(
            'slug'         => isset($remote->slug) ? sanitize_title($remote->slug) : dirname($plugin_basename),
            'plugin'       => $plugin_basename,
            'new_version'  => sanitize_text_field($remote->version),
            'version'      => sanitize_text_field($remote->version),
            'url'          => !empty($remote->homepage) ? esc_url_raw($remote->homepage) : '',
            'package'      => !empty($remote->download_url) ? esc_url_raw($remote->download_url) : '',
            'requires'     => isset($remote->requires) ? sanitize_text_field($remote->requires) : '',
            'requires_php' => isset($remote->requires_php) ? sanitize_text_field($remote->requires_php) : '',
            'tested'       => isset($remote->tested) ? sanitize_text_field($remote->tested) : '',
        );
    }
}
add_filter('update_plugins_wordpress.xz.cn', 'jzp_cf7_wp_58_update', 10, 4);

// 填充插件更新详情页
if (!function_exists('jzp_cf7_plugin_info')) {
    function jzp_cf7_plugin_info($res, $action, $args) {
        if ('plugin_information' !== $action || empty($args->slug)) {
            return $res;
        }

        $plugin_basename = plugin_basename(JZP_CF7_FILE);
        $plugin_slug     = dirname($plugin_basename);
        $update_uri      = 'https://wordpress.xz.cn';

        $slug    = (string) $args->slug;
        $matched = (
            $slug === $plugin_slug ||
            $slug === $plugin_basename ||
            $slug === JZP_CF7_UPDATE_API ||
            $slug === $update_uri ||
            0 === strpos($slug, $update_uri)
        );

        if (!$matched) {
            return $res;
        }

        $remote = jzp_cf7_fetch_update(false);
        if (!$remote || empty($remote->version)) {
            return $res;
        }

        $res                = new stdClass();
        $res->name          = isset($remote->name) ? sanitize_text_field($remote->name) : 'JZP CF7 Manager';
        $res->slug          = $args->slug;
        $res->version       = sanitize_text_field($remote->version);
        $res->author        = isset($remote->author) ? wp_kses_post($remote->author) : 'Jianzhanpress.com';
        $res->download_link = !empty($remote->download_url) ? esc_url_raw($remote->download_url) : '';
        $res->homepage      = !empty($remote->homepage) ? esc_url_raw($remote->homepage) : '';
        $res->requires      = isset($remote->requires) ? sanitize_text_field($remote->requires) : '';
        $res->requires_php  = isset($remote->requires_php) ? sanitize_text_field($remote->requires_php) : '';
        $res->tested        = isset($remote->tested) ? sanitize_text_field($remote->tested) : '';
        $res->last_updated  = isset($remote->last_updated) ? sanitize_text_field($remote->last_updated) : '';

        if (!empty($remote->icons) && is_object($remote->icons)) {
            $res->icons = array();
            foreach (array('1x', '2x', 'svg') as $size) {
                if (!empty($remote->icons->$size)) {
                    $res->icons[$size] = esc_url_raw($remote->icons->$size);
                }
            }
        }

        if (!empty($remote->banners) && is_object($remote->banners)) {
            $res->banners = array();
            foreach (array('low', 'high') as $size) {
                if (!empty($remote->banners->$size)) {
                    $res->banners[$size] = esc_url_raw($remote->banners->$size);
                }
            }
        }

        $sections = array();
        if (!empty($remote->description))    $sections['description']    = wp_kses_post($remote->description);
        if (!empty($remote->installation))   $sections['installation']   = wp_kses_post($remote->installation);
        if (!empty($remote->faq))           $sections['faq']           = wp_kses_post($remote->faq);
        if (!empty($remote->changelog))      $sections['changelog']      = wp_kses_post($remote->changelog);
        $res->sections = $sections;

        if (isset($remote->rating))         $res->rating         = (float) $remote->rating;
        if (isset($remote->num_ratings))    $res->num_ratings    = (int) $remote->num_ratings;
        if (isset($remote->downloaded))     $res->downloaded     = (int) $remote->downloaded;
        if (isset($remote->active_installs)) $res->active_installs = (int) $remote->active_installs;

        return $res;
    }
}
add_filter('plugins_api', 'jzp_cf7_plugin_info', 20, 3);

// 更新完成后清缓存
if (!function_exists('jzp_cf7_clear_update_cache')) {
    function jzp_cf7_clear_update_cache($upgrader_object, $options) {
        if (empty($options['action']) || 'update' !== $options['action']) return;
        if (empty($options['type']) || 'plugin' !== $options['type']) return;

        $plugin_basename = plugin_basename(JZP_CF7_FILE);
        $updated         = isset($options['plugins']) ? (array) $options['plugins'] : array();

        if (in_array($plugin_basename, $updated, true)) {
            delete_transient(JZP_CF7_UPDATE_CACHE_KEY);
        }
    }
}
add_action('upgrader_process_complete', 'jzp_cf7_clear_update_cache', 10, 2);

// 统一 ZIP 解压目录名，避免带版本号的目录残留（仅处理本插件）
if (!function_exists('jzp_cf7_upgrader_source_selection')) {
    function jzp_cf7_upgrader_source_selection($source, $remote_source) {
        global $wp_filesystem;

        if (is_wp_error($source)) return $source;

        $expected_slug = dirname(plugin_basename(JZP_CF7_FILE));
        $source        = untrailingslashit($source);
        $actual_slug   = basename($source);

        if ($actual_slug === $expected_slug) return trailingslashit($source);

        // 只处理本插件的 ZIP：源目录中应包含主插件文件
        $plugin_file = $source . '/' . $expected_slug . '.php';
        if (!$wp_filesystem->exists($plugin_file)) return trailingslashit($source);

        $target = dirname($source) . '/' . $expected_slug;
        if (!$wp_filesystem->move($source, $target)) {
            return new WP_Error('rename_failed', '无法重命名解压目录');
        }

        return trailingslashit($target);
    }
}
add_filter('upgrader_source_selection', 'jzp_cf7_upgrader_source_selection', 10, 2);

// 后台 About tab 版本检查 AJAX
if (!function_exists('jzp_cf7_ajax_check_version')) {
    function jzp_cf7_ajax_check_version() {
        if (!current_user_can('update_plugins')) {
            wp_send_json_error(array('message' => '无权检查'), 403);
        }
        check_ajax_referer('jzp_cf7_check_version', 'nonce');

        if (!function_exists('get_plugin_data')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        delete_transient(JZP_CF7_UPDATE_CACHE_KEY);
        $remote  = jzp_cf7_fetch_update(true);
        $current = get_plugin_data(JZP_CF7_FILE, false, false);

        if (!$remote || empty($remote->version)) {
            wp_send_json_error(array('message' => '无法连接到更新服务器，请稍后再试。'));
        }

        $is_latest = version_compare($remote->version, $current['Version'], '<=');

        $plugin_basename = plugin_basename(JZP_CF7_FILE);
        $upgrade_url     = wp_nonce_url(
            self_admin_url('update.php?action=upgrade-plugin&plugin=' . rawurlencode($plugin_basename)),
            'upgrade-plugin_' . $plugin_basename
        );

        wp_send_json_success(array(
            'current'    => $current['Version'],
            'latest'     => $remote->version,
            'is_latest'  => $is_latest,
            'upgrade_url' => $upgrade_url,
            'homepage'   => !empty($remote->homepage) ? $remote->homepage : '',
        ));
    }
}
add_action('wp_ajax_jzp_cf7_check_version', 'jzp_cf7_ajax_check_version');

// 11. 插件删除时清理数据表（可选）
register_uninstall_hook(__FILE__, 'jzp_cf7_uninstall');
function jzp_cf7_uninstall() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'cf7_messages';
    $wpdb->query("DROP TABLE IF EXISTS $table_name"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.DirectDatabaseQuery.SchemaChange
    delete_option('jzp_cf7_custom_db_version');
    delete_option('jzp_cf7_smtp_settings');
}
