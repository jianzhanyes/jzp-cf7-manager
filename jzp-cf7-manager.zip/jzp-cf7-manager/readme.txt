=== JZP CF7 Manager ===
Contributors: jianzhanpress
Donate link: https://www.jianzhanpress.com/
Tags: contact-form-7, cf7, database, smtp, messages
Requires at least: 7.1
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 1.2.8
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Saves Contact Form 7 submissions to the database with a full admin panel (view, delete, bulk delete, unread badge). Built-in SMTP support.

== Description ==

**JZP CF7 Manager** extends Contact Form 7 with reliable message storage and easy SMTP configuration.

### Why this plugin?

* Contact Form 7 only sends submissions via email — if a message gets lost or deleted, there is no way to recover it. This plugin saves every submission to the database automatically.
* No need to install a separate SMTP plugin. A complete SMTP configuration panel is built right in, with a one-click test email.

### Features

1. **Auto-save CF7 submissions to database** — Every form submission is stored in the `wp_cf7_messages` table.
2. **Admin message management** — View details, single delete, bulk delete.
3. **Unread reminders** — Red badge on the admin menu shows unread count; unread rows are highlighted in yellow.
4. **Built-in SMTP settings** — Visual configuration panel supporting SSL/TLS, with one-click test email.
5. **Self-hosted updates** — Custom update server keeps your plugin up to date.
6. **Safe uninstall** — All data and SMTP settings are cleaned up automatically when uninstalling.

### Requirements

* Contact Form 7 (required)
* WordPress 7.1+
* PHP 8.0+

== Installation ==

1. Go to **Plugins → Add New → Upload Plugin** in your WordPress admin, then upload the ZIP file.
2. Activate the plugin.
3. Make sure **Contact Form 7** is installed and activated.
4. Open the **Messages** menu item on the left sidebar to view and manage submissions.
5. To use the built-in SMTP feature, go to **Messages → SMTP Settings**.

== Screenshots ==

1. Message list screen showing all CF7 submissions, unread highlighting, and bulk actions.
2. Message detail screen with all submitted fields displayed.
3. Admin menu badge showing the unread message count.
4. SMTP settings screen with visual configuration and test email button.
5. About tab on the SMTP settings screen with a manual version check.
6. Help tab on the SMTP settings screen including common SMTP parameters.

== FAQ ==

= Why do I need this plugin? =

Contact Form 7 only emails submissions and does not store them. If the email gets lost, deleted, or the mail server fails, the data is gone forever. This plugin automatically saves all CF7 submissions to the database and provides a full admin interface to manage them.

= Will the plugin create database tables automatically? =

Yes. On first activation, it creates the `wp_cf7_messages` table (the `wp_` prefix may differ depending on your WordPress configuration).

= Will my data be kept after uninstalling the plugin? =

No. When you uninstall/delete the plugin, the database table and all SMTP settings are removed automatically. Back up your database first if you want to keep the data.

= Is SMTP required? =

No. The SMTP feature is optional. If you leave it disabled, WordPress will continue using the default PHP `mail()` function.

= Common SMTP parameters =

| Provider     | Server                  | Port | Encryption |
|--------------|-------------------------|------|------------|
| QQ Mail      | smtp.qq.com             | 465  | SSL        |
| 163 Mail     | smtp.163.com            | 465  | SSL        |
| Gmail        | smtp.gmail.com          | 587  | TLS        |
| Outlook      | smtp.office365.com      | 587  | TLS        |

Note: Use the SMTP authorization code (not your login password). You must generate this code in your email provider's settings page.

== Changelog ==

= 1.2.0 =
* Added unread row highlighting in the message list
* Added "About" and "Help" tabs on the SMTP settings screen
* Added AJAX endpoint for manual version check

= 1.1.0 =
* Added built-in SMTP mail settings (visual configuration + test email)
* Apply SMTP config through the `phpmailer_init` hook

= 1.0.0 =
* First public release
* Auto-save CF7 submissions to database
* Admin message list: view, delete, bulk delete
* Unread badge and auto-mark-as-read
* Self-hosted update support
* Safe uninstall cleanup

== Upgrade Notice ==

= 1.2.0 =
Recommended for all users. Adds unread highlighting and help tabs on the SMTP settings page.

= 1.1.0 =
Recommended for all users. Adds a built-in SMTP panel, so you no longer need a separate SMTP plugin.
